from django.apps import AppConfig


class BtokenConfig(AppConfig):
    name = 'dtoken'
